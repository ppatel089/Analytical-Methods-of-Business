rm(list=ls())
library(readxl)
boats=read_excel("Module 3 Data Sets.xlsx",sheet="Boats")
colnames(boats)=tolower(make.names(colnames(boats)))
attach(boats)
powerboats=subset(boats,class=="Power")
sailboats=subset(boats,class=="Sails")
set.seed(27738410)
my.power=powerboats[sample(1:nrow(powerboats),50,replace=FALSE),]
attach(my.power)
set.seed(27738410)
my.sail=sailboats[sample(1:nrow(sailboats),50,replace=FALSE),]
attach(my.sail)