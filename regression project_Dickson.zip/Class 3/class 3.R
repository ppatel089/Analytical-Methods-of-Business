rm(list=ls())
library(readxl)
gpa50=read_excel("Module 3 Data Sets.xlsx",sheet="GPAs 50 Stacked")
colnames(gpa50)=tolower(make.names(colnames(gpa50)))
attach(gpa50)
t.test(gpas50,mu=2.1,alternative = c("two.sided"))
results=t.test(gpas50,mu=2.1,alternative = c("two.sided"))
names(results)
summary(results)
print(results)
results$p.value
results$conf.int
results$conf.int[1]
results$conf.int[2]
results$conf.int[2]-results$conf.int[1]

iq=read_excel("Module 3 Data Sets.xlsx",sheet="IQ")
colnames(iq)=tolower(make.names(colnames(iq)))
attach(iq)
results=t.test(age.25,age.60,mu=0,alternative = c("two.sided"))
results

rats=read_excel("Module 3 Data Sets.xlsx",sheet="Rat Pups")
colnames(rats)=tolower(make.names(colnames(rats)))
attach(rats)
results=t.test(male,female,mu=0,alternative=c("two.sided"),paired=TRUE)
results
