install.packages("car")
rm(list = ls())
library(readxl)
library(corrplot)
library(Hmisc)
library(car)
wages=read_excel("wages Data.xlsx", sheet="Fixed Data")
colnames(wages)=tolower(make.names(colnames(wages)))
attach(wages)
some.of.wages=subset(wages,select=c("wage","yearsed","experience","age"))
plot(some.of.wages)
cor(some.of.wages)
xx=cor(some.of.wages)
corrplot(xx,method="circle")
corrplot(xx,method="pie")
corrplot(xx,method="ellipse")
corrplot(xx,method="color")
corrplot(xx,method="number")
corrplot(xx,method="square")
corrplot(xx,method="circle",type = "upper")
corrplot(xx,method="circle",type = "lower")
xx=rcorr(as.matrix(some.of.wages))
xx
regout=lm(wage~yearsed+experience+age,data=some.of.wages)
summary(regout)
cor(regout$fitted.values,some.of.wages$wage)^2
plot(some.of.wages$wage,regout$fitted.values)
regout=lm(wage~yearsed+experience+age+union,data=wages)
summary(regout)
regout=lm(wage~yearsed+experience+age+union+sex,data=wages)
summary(regout)
regout=lm(wage~yearsed+experience+age+union+sex+race,data=wages)
summary(regout)
vif(regout)


wages$pm=NA
for(i in 1:length(wages$occupation)){
  wages$pm[i]="Another"
  if(wages$occupation[i]=="Management")
}