rm(list = ls())
library(readxl)
library(corrplot)
mpg=read_excel("6304 Old Auto MPG.xlsx", sheet="Auto MPG")
colnames(mpg)=tolower(make.names(colnames(mpg)))
attach(mpg)
set.seed(27738410)
mpgs = mpg[sample(1:nrow(mpg),100,replace=FALSE),]
mpgs$model.year=as.factor(mpgs$model.year)
some.of.mpgs=subset(mpgs,select=c("mpg","cc.displacement","horsepower","weight","acceleration"))
plot(some.of.mpgs)
xx=cor(some.of.mpgs)
corrplot(xx,method="ellipse")
corrplot(xx,method="number")
mpgs.regout= lm(mpg~cc.displacement+horsepower+acceleration+weight,data=mpgs)
summary(mpgs.regout)
vif(mpgs.regout)
mpgs.regout= lm(mpg~horsepower+acceleration+weight,data=mpgs)
summary(mpgs.regout)
vif(mpgs.regout)
mpgs.regout= lm(mpg~weight+acceleration,data=mpgs)
summary(mpgs.regout)
vif(mpgs.regout)
mpgs.regout= lm(mpg~weight,data=mpgs)
summary(mpgs.regout)
mpgs.regout= lm(mpg~weight+origin,data=mpgs)
summary(mpgs.regout)
mpgs.regout= lm(mpg~weight+model.year,data=mpgs)
summary(mpgs.regout)


mpgs$year=NA
for(i in 1:length(mpgs$model.year)){
  if(mpgs$model.year[i]=="79"||mpgs$model.year[i]=="80"||mpgs$model.year[i]=="81"||mpgs$model.year[i]=="82"){
  if(mpgs$model.year[i]=="79"){
    mpgs$year[i]="79"
  }
  if(mpgs$model.year[i]=="80"){
    mpgs$year[i]="80"
  }
  if(mpgs$model.year[i]=="81"){
    mpgs$year[i]="81"
  }
  if(mpgs$model.year[i]=="82"){
    mpgs$year[i]="82"
  }
  }
  else{
    mpgs$year[i]="Another"
  }
}
cc.displacement+horsepower+weight