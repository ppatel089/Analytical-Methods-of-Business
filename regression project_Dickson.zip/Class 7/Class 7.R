rm(list=ls())
library(readxl)
gold_price=read_excel("6304 Time Series Data Sets.xlsx",sheet="Gold Price")
colnames(gold_price) = tolower(make.names(colnames(gold_price)))
attach(gold_price)
library(car)
plot(time,price)
goldmod1= lm(price ~ time, data=gold_price)
summary(goldmod1)
plot(time, goldmod1$residuals) #no pattern should be visible here; but here there's a trend
abline(0,0)
#plot plots a new graph, points points points on an existing graph.
plot(time, price, type="l")
points(time,goldmod1$fitted.values, type="l", col="red")
cor(gold_price$price, goldmod1$fitted.values)
#linear model isn't working correctly, non-linear model transformation
#squared term

gold_price$time2= gold_price$time^2
goldmod2= lm(price ~ time+time2, data=gold_price)
summary(goldmod2)
plot(time, goldmod2$residuals) # but here there's a trend but less than prev one
abline(0,0)
#plot plots a new graph, points points points on an existing graph.
plot(time, price, type="l",lwd=3)
points(time,goldmod2$fitted.values, type="l", col="red" ,lwd=3) #Here it's fitting
points(time,goldmod1$fitted.values, type="l", col="blue" ,lwd=3)
cor(gold_price$price, goldmod2$fitted.values)


#Milk
rm(list=ls())
library(readxl)
milk=read_excel("6304 Time Series Data Sets.xlsx",sheet="Milk Production 1")
colnames(milk) = tolower(make.names(colnames(milk)))
attach(milk)
View(milk)
plot(milk$time, milk$production, type="o")
milkprod1=lm(production~time, data=milk)
summary(milkprod1)
plot(milk$time,milkprod1$residuals, type="o")
abline(0,0)
plot(milk$time, milk$production, type="o",lwd=3)
points(time, milkprod1$fitted.values,type="l",col="red",lwd=3)
cor(milk$production,milkprod1$fitted.values)
durbinWatsonTest(milkprod1) #for independence
# p>0.05=>errors not autocorrelated=>independence assumtion works

#Seasonal Indexing

indices=data.frame(month=1:12,average=0,index=0)
for(i in 1:12){
  count=0
  for(j in 1:nrow(milk)){
    if(i==milk$month[j]){
      indices$average[i]=indices$average[i]+milk$production[j]
      count=count+1
    }
  }
  indices$average[i]=indices$average[i]/count
  indices$index[i]=indices$average[i]/mean(milk$production)
}
#deseason
for(i in 1:12){
  
  for(j in 1:nrow(milk)){
    if(i==milk$month[j]){
      milk$deseason[j]=milk$production[j]/indices$index[i]
    }
  }
}

#Conducting deseasonalized regression
desregout=lm(deseason ~time, data=milk)
plot(milk$time,desregout$residuals,type="o",lwd=3)
abline(0,0)

durbinWatsonTest(desregout)
plot(milk$time,milk$production,type="o",lwd=3)
points(milk$time,desregout$fitted.values,type="l",col="red")

#reseasonalising

for(j in 1:nrow(milk)){
  xx=milk$month[j]
  milk$reseason.y.hat[j]=desregout$fitted.values[j]*indices$index[xx]
  milk$reseason.error[j]=milk$production[j]-milk$reseason.y.hat[j]
}

plot(milk$time,milk$reaseason.error,type="o")
abline(0,0)
plot(milk$time,milk$production,type="o")
points(milk$time, milk$reseason.y.hat,type="l",col="red")
cor(milk$production,milk$reseason.y.hat)


#trigonometric approach
milk$cosinetime=cos(((2*pi)/12)*milk$time) #12 month cycle
milk$sinetime=sin(((2*pi)/12)*milk$time)
trigregout=lm(production~time+cosinetime+sinetime, data = milk)
plot(milk$time,trigregout$residuals,type="o")
abline(0,0)
durbinWatsonTest(trigregout)
plot(milk$time,milk$production,type="o",lwd=3)
points(milk$time,trigregout$fitted.values,type="l",col="red",lwd=3)
cor(milk$production,trigregout$fitted.values)
View(milk)

#squared term approach
milk$time2=milk$time^2
squaredregout=lm(deseason ~ time+time2,data=milk)
for(j in 1:nrow(milk)){
  xx=milk$month[j]
  milk$sq.reseason.y.hat[j]=squaredregout$fitted.values[j]*indices$index[xx]
  milk$sq.reseason.error[j]=milk$production[j]-milk$sq.reseason.y.hat[j]
}
plot(milk$time,milk$sq.reseason.error,type="o")
abline(0,0)
plot(milk$time,milk$production,type="o",lwd=3)
points(milk$time,milk$sq.reseason.y.hat,type="l",col="red",lwd=3)
cor(milk$production,milk$sq.reseason.y.hat)