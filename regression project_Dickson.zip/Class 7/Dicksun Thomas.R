rm(list=ls())
library(readxl)
library(car)
commodity_price=read_excel("Commodity Price.xlsx",sheet="Price")
colnames(commodity_price) = tolower(make.names(colnames(commodity_price)))
attach(commodity_price)
commodity_price$time<-seq(1,48)
plot(commodity_price$time,commodity_price$price)
indices=data.frame(month=1:4,average=0,index=0)
for(i in 1:4){
  count=0
  for(j in 1:nrow(commodity_price)){
    if(i==commodity_price$quarter[j]){
      indices$average[i]=indices$average[i]+commodity_price$price[j]
      count=count+1
    }
  }
  indices$average[i]=indices$average[i]/count
  indices$index[i]=indices$average[i]/mean(commodity_price$price)
}
#deseason
for(i in 1:4){
  
  for(j in 1:nrow(commodity_price)){
    if(i==commodity_price$quarter[j]){
      commodity_price$deseason[j]=commodity_price$price[j]/indices$index[i]
    }
  }
}

commodity_price$time2=commodity_price$time^2
commodity_price$time3=commodity_price$time^3
commodity.reg=lm(deseason ~ time+time2+time3,data=commodity_price)
summary(commodity.reg)
plot(commodity_price$time, commodity_price$price, type="l",lwd=3)
points(commodity_price$time,commodity.reg$fitted.values, type="l", col="red" ,lwd=3)
for(j in 1:nrow(commodity_price)){
  xx=commodity_price$quarter[j]
  commodity_price$com.reseason.y.hat[j]=commodity.reg$fitted.values[j]*indices$index[xx]
  commodity_price$com.reseason.error[j]=commodity_price$price[j]-commodity_price$com.reseason.y.hat[j]
}
plot(commodity_price$time,commodity_price$com.reseason.error,type="o")
abline(0,0)
plot(commodity_price$time,commodity_price$price,type="o",lwd=3)
points(commodity_price$time,commodity_price$com.reseason.y.hat,type="l",col="red",lwd=3)
cor(commodity_price$price,commodity_price$com.reseason.y.hat)


