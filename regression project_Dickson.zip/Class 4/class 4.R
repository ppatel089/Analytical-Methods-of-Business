rm(list=ls())
library(readxl)
oil=read_excel("Module 4 Data Sets.xlsx",sheet="Oil and Gas")
colnames(oil)=tolower(make.names(colnames(oil)))
attach(oil)
plot(crude,gasoline)
oilout=lm(gasoline~crude)
summary(oilout)
names(oilout)
oilout$coefficients
oilout$coefficients[2]
oilout$fitted.values
oilout$residuals
lm(gasoline~crude,data=oil)

rm(list=ls())
tools=read_excel("Module 4 Data Sets.xlsx",sheet="Cutting Tools")
colnames(tools)=tolower(make.names(colnames(tools)))
attach(tools)
brand.a.out=lm(brand.a~speed)
brand.b.out=lm(brand.b~speed)
brand.a.out$coefficients
brand.b.out$coefficients
plot(speed,brand.a,ylim=c(0,7))
points(speed,brand.b,col="red")
abline(brand.a.out$coefficients[1],brand.a.out$coefficients[2])
abline(brand.b.out$coefficients[1],brand.b.out$coefficients[2],col="red")
abline(brand.a.out)
abline(brand.b.out,col="red")
cor(speed,brand.a);cor(speed,brand.b)

confint(brand.a.out,'speed', level=0.95)
confint(tamil.out, 'Intercept', level=0.95)
confint(brand.a.out)
#this data wont work with regression
x=rnorm(1000,100,10)
y=rnorm(1000,200,20)
plot(x,y);cor(x,y)
regout=lm(y~x)
summary(regout)
abline(regout)
abline(regout,col="red",lwd=3)
qqnorm(resid(regout))
qqline(resid(regout),col="red",lwd=3)

x=rnorm(1000,100,10)
y=x^5
plot(x,y)
cor(x,y)
regout=lm(y~x)
summary(regout)
qqnorm(resid(regout))
qqline(resid(regout),col="red",lwd=3)

#Child Absue
abuse=read_excel("Module 4 Data Sets.xlsx",sheet="Child Abuse")
colnames(abuse)=tolower(make.names(colnames(abuse)))
attach(abuse)
cor(under.18,victims)
abuseout=lm(victims~under.18)
summary(abuseout)
plot(under.18,victims)
abline(abuseout)
stdres=rstandard((abuseout))
plot(abuse$under.18,stdres,ylim=c(-5,5))
abline(0,0,col="red",lwd=3)

newdata=data.frame(under.18=500000)
predict(abuseout,newdata,interval="predict")
predict(abuseout,newdata,interval="confidence")
