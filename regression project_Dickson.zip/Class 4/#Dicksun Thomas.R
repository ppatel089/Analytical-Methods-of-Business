rm(list=ls())
library(readxl)
tamilanatomy=read_excel("Module 4 Data Sets.xlsx",sheet="Tamil Anatomy")
colnames(tamilanatomy)=tolower(make.names(colnames(tamilanatomy)))
attach(tamilanatomy)
set.seed(27738410)
tamilanatomy.df = tamilanatomy[sample(1:nrow(tamilanatomy),50,replace=FALSE),]
tamilanatomy.df$footlength <- tamilanatomy.df$left.foot.length*0.393701
tamilanatomy.df$heightinch <- tamilanatomy.df$height*0.393701
a<-tamilanatomy.df$footlength
x<-tamilanatomy.df$heightinch
#1st Question
cor.test(a,x)
#2nd Question
tamil.out=lm(a~x)
summary(tamil.out)
confint(tamil.out)

plot(x,a,main = "ScatterPlot",xlab = "Height(inches)",ylab = "Length of left foot(inches)")
abline(tamil.out, col="red", lwd=3)
par(mfrow=c(2,2))
plot(tamil.out)

newdata=data.frame(x=66,55)
predict(tamil.out,newdata,interval="predict")



