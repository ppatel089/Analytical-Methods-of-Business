#DICKSUN THOMAS
means.30=data.frame()
for(i in 1:500){
  data.30 = runif(30,0,1)
  means.30[i,1]=mean(data.30)
}
hist(means.30$V1,col="yellow",xlim = c(.30,0.80),main="Histogram of means.30",xlab = "Means.30")
mean(means.30$V1)

means.50=data.frame()
for(i in 1:500){
  data.50 = runif(50,0,1)
  means.50[i,1]=mean(data.50)
}
hist(means.50$V1,col="red",xlim = c(.30,0.80),main="Histogram of means.50",xlab = "Means.50")
mean(means.50$V1)

means.100=data.frame()
for(i in 1:500){
  data.100 = runif(100,0,1)
  means.100[i,1]=mean(data.100)
}
hist(means.100$V1,col="blue",xlim = c(.30,0.80),main="Histogram of means.100",xlab = "Means.100")
mean(means.100$V1)


xx=rnorm(1000,1000,100)
qqnorm(xx)
qqline(xx,col="red",lwd=2)
hist(xx,col="green")

pnorm(550,500,40)
pnorm(550,500,40)-pnorm(480,500,40)
