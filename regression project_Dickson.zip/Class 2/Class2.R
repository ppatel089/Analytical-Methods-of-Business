pnorm(36,72,14)
pnorm(48,72,14)
pnorm(48,78,14)
pnorm(48,72,9)
dnorm(48,78,14)
rnorm(5,72,14)
curve(dnorm(x,72,14),from=30,to=120,lwd=3,ylim=c(0,.07))
curve(dnorm(x,78,9),from=30,to=120,lwd=3,col="red",add=TRUE)
xx=rnorm(5000,72,14)
mean(xx)
sd(xx)
hist(xx,col="red",main="My Histogram",xlab = "These numbers in xx")
qqnorm(xx)
qqline(xx,col="red",lwd=3)
yy=runif(5000,0,1)
hist(yy)
qqnorm(yy)
qqline(yy,col="red",lwd=3)
punif(.4,0,1)
punif(.4,0,2)
punif(.4,0,2,lower.tail=FALSE)
curve(dunif(x,0,1),from=0,to=1,lwd=3)
curve(dunif(x,0,1),from=.5,to=1.5,lwd=3,xlim = c(-.5,1.4))
curve(dnorm(x,72,14),from=30,to=120,lwd=3,ylim=c(0,.05))
for(i in 8:13){  
  curve(dnorm(x,72,i),from=30,to=120,lwd=3,add=TRUE)
}
curve(dweibull(x,shape=3,scale=5),from=0,to=20,lwd=3)
curve(dweibull(x,shape=3,scale=5),from=0,to=20,lwd=3,ylim=c(0,.5))
for(i in 1:5){
  curve(dweibull(x,shape=i,scale=5),from=0,to=20,lwd=3,add=TRUE)
}
mydata=data.frame()
for(i in 1:1000){
  mydata[i,1]=i*2
  }
mydata[750,1]
View(mydata)
?punif

