install.packages("data.table")
install.packages("corrplot")
library(corrplot)
3par(mfrow=c(2,2))

#DICKSUN THOMAS
rm(list = ls())
par(mfrow=c(1,1))
library(data.table)
library(readxl)
popdata = read_excel("Regression project.xls", sheet = "Sheet1")
colnames(popdata) = tolower(make.names(colnames(popdata)))
attach(popdata)
#1st Question
popdata$whitepr = (popdata$popwhite/popdata$poptotal)*100
popdata$blackpr = (popdata$popblack/popdata$poptotal)*100
popdata$amerindpr = (popdata$popamerindian/popdata$poptotal)*100
popdata$asianpr = (popdata$popasian/popdata$poptotal)*100
popdata$otherpr = (popdata$popother/popdata$poptotal)*100
popdata$adultspr = (popdata$popadults/popdata$poptotal)*100
popdata$childrenpr = (popdata$popchild/popdata$poptotal)*100
#2nd Question
Illinois = subset(popdata, state == "IL")
Indiana = subset(popdata, state == "IN")
#3rd Question
set.seed(27738410)
My.Illinois = Illinois[sample(1:nrow(Illinois),0.2*nrow(Illinois),replace=FALSE),]
My.Indiana = Indiana[sample(1:nrow(Indiana),0.2*nrow(Indiana),replace=FALSE),]
#4th Question
Question4 = t.test(My.Illinois$area,alternative = c("two.sided"))
Question4
mean(Illinois$area)
#5th Question
Question5 = t.test((My.Indiana$poptotal),(My.Illinois$poptotal), mu=0,alternative = c("two.sided"))
Question5
#6th Question
x<- Illinois$percollege
y<- Illinois$perprof
prof.out = lm(y~x)
summary(prof.out)
cor(Illinois$percollege,Illinois$perprof)
mean(Illinois$percollege)
newdata=data.frame(x=19.78814)
predict(prof.out,newdata,interval="predict")
newdata1=data.frame(x=18.78814)
predict(prof.out,newdata1,interval="predict")
plot(prof.out$fitted.values,prof.out$residuals)
abline(0,0, lwd=3, col="red")
plot(Illinois.md$perchildpovert,Illinoisfinal.reg$residuals)
abline(0,0, lwd=3, col="red")
qqnorm(resid(Illinoisfinal.reg))
qqline(resid(Illinoisfinal.reg),lwd=3,col="Red")

plot(prof.out)
#7th Question
Illinois.md <- Illinois
setDT(Illinois.md)
Illinois.md
todelete1 <- names(Illinois.md)[which(sapply(Illinois.md,uniqueN)<2)]
if(!length(todelete1)==0){
  print(todelete1)
  Illinois.md[,(todelete1) := NULL]
}
Illinois.reg = lm(perchildpovert~.-id-county-inmetro-poptotal-popdensity-popasian-popblack-popother-popamerindian-popadults-popchild-popwhite, data = Illinois.md)
summary(Illinois.reg)
Illinoisfinal.reg = lm(perchildpovert~perpoverty+blackpr+adultspr, data = Illinois.md)
summary(Illinoisfinal.reg)
plot(Illinoisfinal.reg$fitted.values,Illinoisfinal.reg$residuals)
abline(0,0, lwd=3, col="red")
plot(Illinois.md$perchildpovert,Illinoisfinal.reg$residuals)
abline(0,0, lwd=3, col="red")
qqnorm(resid(Illinoisfinal.reg))
qqline(resid(Illinoisfinal.reg),lwd=3,col="Red")

Indiana.md <- Indiana
setDT(Indiana.md)
todelete2 <- names(Indiana.md)[which(sapply(Indiana.md,uniqueN)<2)]
if(!length(todelete2)==0){
  print(todelete2)
  Indiana.md[,(todelete2) := NULL]
}
Indianafinal.reg = lm(perchildpovert~perpoverty+blackpr+adultspr, data = Indiana.md)
summary(Indianafinal.reg)

plot(Indianafinal.reg$fitted.values,Indianafinal.reg$residuals)
abline(0,0, lwd=3, col="red")
plot(Indiana.md$perchildpovert,Indianafinal.reg$residuals)
abline(0,0, lwd=3, col="red")
qqnorm(resid(Indianafinal.reg))
qqline(resid(Indianafinal.reg),lwd=3,col="Red")



cor(Illinois.md$perpoverty,Illinois.md$perelderlypoverty)
qqnorm(My.Illinois$poptotal)
hist(Illinois$percollege)
hist(log(Illinois$percollege))
hist((Illinois$perchildpovert))


plot(Illinois.md$perpoverty,resid(Illinois.reg))
abline(0,0)


sqrt(mean(Illinois.reg$residuals^2))

chek.reg = lm((perchildpovert)~perpoverty+(perelderlypoverty)+adultspr, data = Illinois.md)
summary(chek.reg)
plot(chek.reg)

cor(Illinois.md$perpoverty,Illinois.md$peradultpoverty)
cor(Illinois.md$perpoverty,Illinois.md$perelderlypoverty)
log(Illinois.md[,c(-2,-19)])
illi <- log(Illinois.md[,c(-2,-19)])
illi
Illinois.md

cor(Illinois.md$percollege,Illinois.md$perprof)


install.packages("corrplot")
library(corrplot)
newdata.cor<-Illinois[,c(14,15,16,17,18,19,21,22,23,24,25,26)]
summary(newdata.cor)
correlation=cor(newdata.cor)
corrplot::corrplot(correlation,method="number")


view(newdata.cor)
newdata7


plot(Illinoisfinal.reg)


illinois.w <-Illinois
illinois.w$popchildpovert = (illinois.w$perchildpovert/100)*illinois.w$popchild
illinois.w$state<-NULL
illreg = lm(popchildpovert~.-id-county-inmetro-, data = illinois.w)
summary(illreg)
