rm(list = ls())
library(readxl)
boats=read_excel("Module 5 Data Sets.xlsx", sheet="Boats")
colnames(boats) = tolower(make.names(colnames(boats)))
attach(boats)
floridaboats=subset(boats, state=="FL" & category=="Commercial Boats" & class=="Power" | class=="Sails")
set.seed(27738410)
floridaboats.df = floridaboats[sample(1:nrow(floridaboats),200,replace=FALSE),]
#lm with class
boatsclass.out=lm(price~class, data=floridaboats.df)
summary(boatsclass.out)
#lm with length
boatslength.out=lm(price~length, data=floridaboats.df)
summary(boatslength.out)
#lm with age
boatsage.out=lm(price~age, data=floridaboats.df)
summary(boatsage.out)
#lm with class and length
boatsclln.out=lm(price~class+length, data=floridaboats.df)
summary(boatsclln.out)
#lm with class and age
boatsclag.out=lm(price~class+age, data=floridaboats.df)
summary(boatsclag.out)
#lm with length and age
boatslnag.out=lm(price~length+age, data=floridaboats.df)
summary(boatslnag.out)
#lm with length, age and Class
boatscllnag.out=lm(price~class+length+age, data=floridaboats.df)
summary(boatscllnag.out)

#2nd Question
par(mfrow=c(1,2))
plot(floridaboats.df$length,floridaboats.df$price)
abline(boatslnag.out, col="red", lwd=3)
plot(floridaboats.df$age,floridaboats.df$price)
abline(boatslnag.out, col="red", lwd=3)
par(mfrow=c(1,1))
plot(boatslnag.out$fitted.values,boatslnag.out$residuals)
abline(0,0,lwd=3,col="red")
xx=rstandard(boatslnag.out)
plot(boatslnag.out$fitted.values,xx)
abline(0,0,lwd=3,col="red")
qqnorm(xx)
qqline(xx,lwd=3,col="red")

#3rd Question
x=floridaboats.df$length
a=floridaboats.df$age
y=floridaboats.df$price
boatslnag.out=lm(y~x+a)
summary(boatslnag.out)
newdata=data.frame(x=63,a=30)
predict(boatslnag.out,newdata,interval="predict")
predict(boatslnag.out,newdata,interval="confidence")

